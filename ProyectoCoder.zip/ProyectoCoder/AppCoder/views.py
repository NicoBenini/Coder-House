from http.client import HTTPResponse
from django.shortcuts import render

# Create your views here.
from models import Curso

def curso(self):
    
    curso = Curso(nombre = "Desarrllo web", camada = "19881")
    curso.save()
    documentoDeTexto = f"--->Curso: {curso.nombre} Camada: {curso.camada}"
    
    return HTTPResponse(documentoDeTexto)